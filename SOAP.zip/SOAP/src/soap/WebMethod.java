package soap;

public @interface WebMethod {

}

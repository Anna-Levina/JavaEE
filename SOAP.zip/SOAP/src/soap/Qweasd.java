package soap;

public class Qweasd {
	public static String string ="Privet";
}

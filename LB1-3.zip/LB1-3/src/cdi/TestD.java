package cdi;

@Alternative
public class TestD implements TestCDI {
	@Inject
	private final TestCDI testCDI;
	@Override
	public String editDoctor(String doctor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String editPacient(String pacient) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String editPriyom(String priyom) {
		// TODO Auto-generated method stub
		return null;
	}
	

}

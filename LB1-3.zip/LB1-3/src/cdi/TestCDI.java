package cdi;

public interface TestCDI {
	String editDoctor(String doctor);
	String editPriyom(String priyom);
	String editPacient(String pacient);

}

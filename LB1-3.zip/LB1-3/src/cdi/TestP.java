package cdi;
@Named("TestP")
public class TestP implements TestCDI {

	@Override
	public String editDoctor(String doctor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String editPacient(String pacient) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String editPriyom(String priyom) {
		// TODO Auto-generated method stub
		return null;
	}

}

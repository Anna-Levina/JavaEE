package ejb3_2_components;

public interface PropertyRegistry {

}
